//
//  DetailsVC.swift
//  Beepz
//
//  Created by Anamul Habib on 19/1/22.
//

import UIKit

class DetailsVC: BaseViewController {

    @IBOutlet weak var orderNumberLbl: UILabel!
    @IBOutlet weak var secondView: UIView!
    @IBOutlet weak var iconBGView: UIView!
    @IBOutlet weak var curveView: CurvedHeaderView!
    @IBOutlet weak var topView: UIView!
    
    @IBOutlet weak var levelOneTitle: UILabel!
    @IBOutlet weak var levelOneIcon: UIImageView!
    @IBOutlet weak var levelOneCheckBoxIcon: UIImageView!
    @IBOutlet weak var levelOneBar: UIView!
    
    @IBOutlet weak var levelTwoTitle: UILabel!
    @IBOutlet weak var levelTwoIcon: UIImageView!
    @IBOutlet weak var levelTwoCheckBoxIcon: UIImageView!
    @IBOutlet weak var levelTwoBar: UIView!
    
    @IBOutlet weak var levelThreeTitle: UILabel!
    @IBOutlet weak var levelThreeIcon: UIImageView!
    @IBOutlet weak var levelThreeCheckBoxIcon: UIImageView!
    @IBOutlet weak var levelThreeBar: UIView!
    
    @IBOutlet weak var levelFourTitle: UILabel!
    @IBOutlet weak var levelFourIcon: UIImageView!
    @IBOutlet weak var levelFourCheckBoxIcon: UIImageView!
    @IBOutlet weak var levelFourBar: UIView!
    
    @IBOutlet weak var levelFiveTitle: UILabel!
    @IBOutlet weak var levelFiveIcon: UIImageView!
    @IBOutlet weak var levelFiveCheckBoxIcon: UIImageView!
    @IBOutlet weak var levelFiveBar: UIView!
    
    @IBOutlet weak var levelSixTitle: UILabel!
    @IBOutlet weak var levelSixIcon: UIImageView!
    @IBOutlet weak var levelSixCheckBoxIcon: UIImageView!
    @IBOutlet weak var levelSixBar: UIView!
    
    @IBOutlet weak var levelSevenTitle: UILabel!
    @IBOutlet weak var levelSevenIcon: UIImageView!
    @IBOutlet weak var levelSevenCheckBoxIcon: UIImageView!
    @IBOutlet weak var levelSevenBar: UIView!
    
    @IBOutlet weak var levelEightTitle: UILabel!
    @IBOutlet weak var levelEightIcon: UIImageView!
    @IBOutlet weak var levelEightCheckBoxIcon: UIImageView!
    @IBOutlet weak var levelEightBar: UIView!
    
    @IBOutlet weak var levelNineTitle: UILabel!
    @IBOutlet weak var levelNineIcon: UIImageView!
    @IBOutlet weak var levelNineCheckBoxIcon: UIImageView!

    
//    override var navigationBarTitleViewImage: UIImage?{
//        return #imageLiteral(resourceName: "beepz")
//    }
    
    var singleServiceData: beepzModelData?
    
    override func viewDidLoad() {
        super.viewDidLoad()

//        initUI()
        
        secondView.layer.masksToBounds = true
        secondView.layer.cornerRadius = 40
        secondView.layer.maskedCorners = [.layerMinXMinYCorner, .layerMaxXMinYCorner]
        
        iconBGView.layer.masksToBounds = true
        iconBGView.layer.cornerRadius = iconBGView.frame.size.height/2
        
        curveView.layer.masksToBounds = true
        curveView.layer.cornerRadius = 24
        
        topView.layer.masksToBounds = true
        topView.layer.cornerRadius = 20
        topView.addViewShadow()
        
        updateUI()
        
    }
    override func viewWillAppear(_ animated: Bool) {
        
        super.viewWillAppear(animated)
        
        makeNavigationBarTransparent()
    }
    
    func updateUI(){
        
        self.orderNumberLbl.text = singleServiceData?.readableOrderNo
        
        if singleServiceData?.orderTrack?.level == 1{
            levelOneTitle.textColor = K.UI.PrimaryTintColor
            levelOneIcon.tintColor = K.UI.PrimaryTintColor
            levelOneCheckBoxIcon.image = UIImage(named: "check")
            levelOneBar.backgroundColor = .black
        }else if singleServiceData?.orderTrack?.level == 2{
            levelOneTitle.textColor = K.UI.PrimaryTintColor
            levelOneIcon.tintColor = K.UI.PrimaryTintColor
            levelOneCheckBoxIcon.image = UIImage(named: "check")
            levelOneBar.backgroundColor = .black
            
            levelTwoTitle.textColor = K.UI.PrimaryTintColor
            levelTwoIcon.tintColor = K.UI.PrimaryTintColor
            levelTwoCheckBoxIcon.image = UIImage(named: "check")
            levelTwoBar.backgroundColor = .black
        }else if singleServiceData?.orderTrack?.level == 3{
            levelOneTitle.textColor = K.UI.PrimaryTintColor
            levelOneIcon.tintColor = K.UI.PrimaryTintColor
            levelOneCheckBoxIcon.image = UIImage(named: "check")
            levelOneBar.backgroundColor = .black
            
            levelTwoTitle.textColor = K.UI.PrimaryTintColor
            levelTwoIcon.tintColor = K.UI.PrimaryTintColor
            levelTwoCheckBoxIcon.image = UIImage(named: "check")
            levelTwoBar.backgroundColor = .black
            
            levelThreeTitle.textColor = K.UI.PrimaryTintColor
            levelThreeIcon.tintColor = K.UI.PrimaryTintColor
            levelThreeCheckBoxIcon.image = UIImage(named: "check")
            levelThreeBar.backgroundColor = .black
        }else if singleServiceData?.orderTrack?.level == 4{
            levelOneTitle.textColor = K.UI.PrimaryTintColor
            levelOneIcon.tintColor = K.UI.PrimaryTintColor
            levelOneCheckBoxIcon.image = UIImage(named: "check")
            levelOneBar.backgroundColor = .black
            
            levelTwoTitle.textColor = K.UI.PrimaryTintColor
            levelTwoIcon.tintColor = K.UI.PrimaryTintColor
            levelTwoCheckBoxIcon.image = UIImage(named: "check")
            levelTwoBar.backgroundColor = .black
            
            levelThreeTitle.textColor = K.UI.PrimaryTintColor
            levelThreeIcon.tintColor = K.UI.PrimaryTintColor
            levelThreeCheckBoxIcon.image = UIImage(named: "check")
            levelThreeBar.backgroundColor = .black
            
            levelFourTitle.textColor = K.UI.PrimaryTintColor
            levelFourIcon.tintColor = K.UI.PrimaryTintColor
            levelFourCheckBoxIcon.image = UIImage(named: "check")
            levelFourBar.backgroundColor = .black
        }else if singleServiceData?.orderTrack?.level == 5{
            levelOneTitle.textColor = K.UI.PrimaryTintColor
            levelOneIcon.tintColor = K.UI.PrimaryTintColor
            levelOneCheckBoxIcon.image = UIImage(named: "check")
            levelOneBar.backgroundColor = .black
            
            levelTwoTitle.textColor = K.UI.PrimaryTintColor
            levelTwoIcon.tintColor = K.UI.PrimaryTintColor
            levelTwoCheckBoxIcon.image = UIImage(named: "check")
            levelTwoBar.backgroundColor = .black
            
            levelThreeTitle.textColor = K.UI.PrimaryTintColor
            levelThreeIcon.tintColor = K.UI.PrimaryTintColor
            levelThreeCheckBoxIcon.image = UIImage(named: "check")
            levelThreeBar.backgroundColor = .black
            
            levelFourTitle.textColor = K.UI.PrimaryTintColor
            levelFourIcon.tintColor = K.UI.PrimaryTintColor
            levelFourCheckBoxIcon.image = UIImage(named: "check")
            levelFourBar.backgroundColor = .black
            
            levelFiveTitle.textColor = K.UI.PrimaryTintColor
            levelFiveIcon.tintColor = K.UI.PrimaryTintColor
            levelFiveCheckBoxIcon.image = UIImage(named: "check")
            levelFiveBar.backgroundColor = .black
        }else if singleServiceData?.orderTrack?.level == 6{
            levelOneTitle.textColor = K.UI.PrimaryTintColor
            levelOneIcon.tintColor = K.UI.PrimaryTintColor
            levelOneCheckBoxIcon.image = UIImage(named: "check")
            levelOneBar.backgroundColor = .black
            
            levelTwoTitle.textColor = K.UI.PrimaryTintColor
            levelTwoIcon.tintColor = K.UI.PrimaryTintColor
            levelTwoCheckBoxIcon.image = UIImage(named: "check")
            levelTwoBar.backgroundColor = .black
            
            levelThreeTitle.textColor = K.UI.PrimaryTintColor
            levelThreeIcon.tintColor = K.UI.PrimaryTintColor
            levelThreeCheckBoxIcon.image = UIImage(named: "check")
            levelThreeBar.backgroundColor = .black
            
            levelFourTitle.textColor = K.UI.PrimaryTintColor
            levelFourIcon.tintColor = K.UI.PrimaryTintColor
            levelFourCheckBoxIcon.image = UIImage(named: "check")
            levelFourBar.backgroundColor = .black
            
            levelFiveTitle.textColor = K.UI.PrimaryTintColor
            levelFiveIcon.tintColor = K.UI.PrimaryTintColor
            levelFiveCheckBoxIcon.image = UIImage(named: "check")
            levelFiveBar.backgroundColor = .black
            
            levelSixTitle.textColor = K.UI.PrimaryTintColor
            levelSixIcon.tintColor = K.UI.PrimaryTintColor
            levelSixCheckBoxIcon.image = UIImage(named: "check")
            levelSixBar.backgroundColor = .black
        }else if singleServiceData?.orderTrack?.level == 7{
            levelOneTitle.textColor = K.UI.PrimaryTintColor
            levelOneIcon.tintColor = K.UI.PrimaryTintColor
            levelOneCheckBoxIcon.image = UIImage(named: "check")
            levelOneBar.backgroundColor = .black
            
            levelTwoTitle.textColor = K.UI.PrimaryTintColor
            levelTwoIcon.tintColor = K.UI.PrimaryTintColor
            levelTwoCheckBoxIcon.image = UIImage(named: "check")
            levelTwoBar.backgroundColor = .black
            
            levelThreeTitle.textColor = K.UI.PrimaryTintColor
            levelThreeIcon.tintColor = K.UI.PrimaryTintColor
            levelThreeCheckBoxIcon.image = UIImage(named: "check")
            levelThreeBar.backgroundColor = .black
            
            levelFourTitle.textColor = K.UI.PrimaryTintColor
            levelFourIcon.tintColor = K.UI.PrimaryTintColor
            levelFourCheckBoxIcon.image = UIImage(named: "check")
            levelFourBar.backgroundColor = .black
            
            levelFiveTitle.textColor = K.UI.PrimaryTintColor
            levelFiveIcon.tintColor = K.UI.PrimaryTintColor
            levelFiveCheckBoxIcon.image = UIImage(named: "check")
            levelFiveBar.backgroundColor = .black
            
            levelSixTitle.textColor = K.UI.PrimaryTintColor
            levelSixIcon.tintColor = K.UI.PrimaryTintColor
            levelSixCheckBoxIcon.image = UIImage(named: "check")
            levelSixBar.backgroundColor = .black
            
            levelSevenTitle.textColor = K.UI.PrimaryTintColor
            levelSevenIcon.tintColor = K.UI.PrimaryTintColor
            levelSevenCheckBoxIcon.image = UIImage(named: "check")
            levelSevenBar.backgroundColor = .black
        }else if singleServiceData?.orderTrack?.level == 8{
            levelOneTitle.textColor = K.UI.PrimaryTintColor
            levelOneIcon.tintColor = K.UI.PrimaryTintColor
            levelOneCheckBoxIcon.image = UIImage(named: "check")
            levelOneBar.backgroundColor = .black
            
            levelTwoTitle.textColor = K.UI.PrimaryTintColor
            levelTwoIcon.tintColor = K.UI.PrimaryTintColor
            levelTwoCheckBoxIcon.image = UIImage(named: "check")
            levelTwoBar.backgroundColor = .black
            
            levelThreeTitle.textColor = K.UI.PrimaryTintColor
            levelThreeIcon.tintColor = K.UI.PrimaryTintColor
            levelThreeCheckBoxIcon.image = UIImage(named: "check")
            levelThreeBar.backgroundColor = .black
            
            levelFourTitle.textColor = K.UI.PrimaryTintColor
            levelFourIcon.tintColor = K.UI.PrimaryTintColor
            levelFourCheckBoxIcon.image = UIImage(named: "check")
            levelFourBar.backgroundColor = .black
            
            levelFiveTitle.textColor = K.UI.PrimaryTintColor
            levelFiveIcon.tintColor = K.UI.PrimaryTintColor
            levelFiveCheckBoxIcon.image = UIImage(named: "check")
            levelFiveBar.backgroundColor = .black
            
            levelSixTitle.textColor = K.UI.PrimaryTintColor
            levelSixIcon.tintColor = K.UI.PrimaryTintColor
            levelSixCheckBoxIcon.image = UIImage(named: "check")
            levelSixBar.backgroundColor = .black
            
            levelSevenTitle.textColor = K.UI.PrimaryTintColor
            levelSevenIcon.tintColor = K.UI.PrimaryTintColor
            levelSevenCheckBoxIcon.image = UIImage(named: "check")
            levelSevenBar.backgroundColor = .black
            
            levelEightTitle.textColor = K.UI.PrimaryTintColor
            levelEightIcon.tintColor = K.UI.PrimaryTintColor
            levelEightCheckBoxIcon.image = UIImage(named: "check")
            levelEightBar.backgroundColor = .black
        }else if singleServiceData?.orderTrack?.level == 9{
            levelOneTitle.textColor = K.UI.PrimaryTintColor
            levelOneIcon.tintColor = K.UI.PrimaryTintColor
            levelOneCheckBoxIcon.image = UIImage(named: "check")
            levelOneBar.backgroundColor = .black
            
            levelTwoTitle.textColor = K.UI.PrimaryTintColor
            levelTwoIcon.tintColor = K.UI.PrimaryTintColor
            levelTwoCheckBoxIcon.image = UIImage(named: "check")
            levelTwoBar.backgroundColor = .black
            
            levelThreeTitle.textColor = K.UI.PrimaryTintColor
            levelThreeIcon.tintColor = K.UI.PrimaryTintColor
            levelThreeCheckBoxIcon.image = UIImage(named: "check")
            levelThreeBar.backgroundColor = .black
            
            levelFourTitle.textColor = K.UI.PrimaryTintColor
            levelFourIcon.tintColor = K.UI.PrimaryTintColor
            levelFourCheckBoxIcon.image = UIImage(named: "check")
            levelFourBar.backgroundColor = .black
            
            levelFiveTitle.textColor = K.UI.PrimaryTintColor
            levelFiveIcon.tintColor = K.UI.PrimaryTintColor
            levelFiveCheckBoxIcon.image = UIImage(named: "check")
            levelFiveBar.backgroundColor = .black
            
            levelSixTitle.textColor = K.UI.PrimaryTintColor
            levelSixIcon.tintColor = K.UI.PrimaryTintColor
            levelSixCheckBoxIcon.image = UIImage(named: "check")
            levelSixBar.backgroundColor = .black
            
            levelSevenTitle.textColor = K.UI.PrimaryTintColor
            levelSevenIcon.tintColor = K.UI.PrimaryTintColor
            levelSevenCheckBoxIcon.image = UIImage(named: "check")
            levelSevenBar.backgroundColor = .black
            
            levelEightTitle.textColor = K.UI.PrimaryTintColor
            levelEightIcon.tintColor = K.UI.PrimaryTintColor
            levelEightCheckBoxIcon.image = UIImage(named: "check")
            levelEightBar.backgroundColor = .black
            
            levelNineTitle.textColor = K.UI.PrimaryTintColor
            levelNineIcon.tintColor = K.UI.PrimaryTintColor
            levelNineCheckBoxIcon.image = UIImage(named: "check")
        }
    }
}
