//
//  HomeVC.swift
//  Beepz
//
//  Created by Rakib on 17/1/22.
//

import UIKit

class HomeVC: BaseViewController {

    
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var thirdView: UIView!
    @IBOutlet weak var secondView: UIView!
    
    
    var serviceData: [beepzModelData]?
    
    
    
    override var shouldShowBackButtonTitle: Bool{
        return false
    }
    
//    override var navigationBarTitleViewImage: UIImage?{
//        return #imageLiteral(resourceName: "icon")
//    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
//        navTitleWithImage()
        
        secondView.layer.masksToBounds = true
        secondView.layer.cornerRadius = 40
        secondView.layer.maskedCorners = [.layerMinXMinYCorner, .layerMaxXMinYCorner]
        
        thirdView.layer.masksToBounds = true
//        thirdView.addViewShadow()
        thirdView.layer.cornerRadius = 40
        thirdView.layer.maskedCorners = [.layerMinXMinYCorner, .layerMaxXMinYCorner]
        
        fetchData()
        
    }

    override func viewWillAppear(_ animated: Bool) {
        
        super.viewWillAppear(animated)
        
        makeNavigationBarTransparent()
    }
    
    func fetchData(){
        webserviceHandler.fetchService(onCompletion: { response in
            if response.code == 200{
                print(response.data?.data?.count)
                self.serviceData = response.data?.data
                
                self.tableView.delegate = self
                self.tableView.dataSource = self
                self.tableView.reloadData()
                
            }else{
                print(response.code)
            }
        }, onFailure: { error in
            print(error?.localizedDescription)
        }, shouldShowLoader: true)
    }
    
}

extension HomeVC: UITableViewDelegate, UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.serviceData?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "tableViewCell", for: indexPath) as! tableViewCell
        let service = serviceData?[indexPath.row]
        cell.titleLbl.text = service?.service?.serviceName
        cell.detailsLbl.text = "Car details: \(service?.car?.vehicleBrand?.brandName ?? "") (\(service?.car?.vehicleModel?.modelName ?? ""))"
        
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.dateFormat = "mm/dd/yyyy HH:mm:ss a"
        let date = formatter.date(from: service?.bookingDate ?? "")
        formatter.dateFormat = "yyyy MMMM dd"
        let dateStr = formatter.string(from: date!)
        
        cell.dateLbl.text = "Date of service: \(dateStr)"
        
        cell.statusLbl.text = service?.orderTrack?.name
        
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "DetailsVC") as! DetailsVC
        
        vc.singleServiceData = serviceData?[indexPath.row]
        
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
}


