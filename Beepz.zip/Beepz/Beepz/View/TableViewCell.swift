//
//  TableViewCell.swift
//  Beepz
//
//  Created by Anamul Habib on 20/1/22.
//

import UIKit

class tableViewCell: UITableViewCell {
    
    @IBOutlet weak var iconConView: UIView!
    @IBOutlet weak var curveView: CurvedHeaderView!
    @IBOutlet weak var bgView: UIView!
    
    @IBOutlet weak var titleLbl: UILabel!
    @IBOutlet weak var detailsLbl: UILabel!
    @IBOutlet weak var dateLbl: UILabel!
    @IBOutlet weak var statusLbl: UILabel!
    @IBOutlet weak var iconImgView: UIImageView!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        iconConView.layer.masksToBounds = true
        iconConView.layer.cornerRadius = iconConView.frame.height/2
        bgView.layer.cornerRadius = 24
        curveView.layer.masksToBounds = true
        curveView.layer.cornerRadius = 24
        bgView.addViewShadow()

    }
}
