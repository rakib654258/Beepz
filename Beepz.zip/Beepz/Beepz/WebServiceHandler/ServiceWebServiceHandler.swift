//
//  ServiceWebServiceHandler.swift
//
//  Beepz
//
//  Created by Rakib on 17/1/22.
//

import Foundation
import Alamofire
import UIKit

extension WebServiceHandler{
    
    func fetchService(onCompletion completion: @escaping (_ response: beepzModel) -> Void, onFailure failure: @escaping (Error?) -> Void, shouldShowLoader: Bool){
        
        performRequest(requestBuilder: ServiceRouter.fetchService.requestBuilder, onCompletion: { (data) in
            
            do{
                if let data = data{
                    
                    let result = try JSONDecoder().decode(beepzModel.self, from: data)
                    
                    DispatchQueue.main.async {
                        completion(result)
                    }
                }
            }catch let error{
                DispatchQueue.main.async {
                    failure(error)
                }
            }
        }, onFailure: { (error) in
            
            DispatchQueue.main.async {
                failure(error)
            }
        }, showLoader: shouldShowLoader)
    }
}
