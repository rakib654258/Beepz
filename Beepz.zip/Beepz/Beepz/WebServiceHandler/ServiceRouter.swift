//
//  ServiceRouter.swift
//
//  Beepz
//
//  Created by Rakib on 17/1/22.
//

import Foundation
import UIKit

enum ServiceRouter{
    
    case fetchService
    
    var requestBuilder: RequestBuilder{
        switch self{
          
        case .fetchService:
            return .init(baseUrl: .Beepz, path: "Get/Customer/active/request", method: .get, params: ["CustomerId":34])
            
        }
    }
}
