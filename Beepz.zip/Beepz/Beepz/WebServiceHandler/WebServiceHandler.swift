//
//  WebServiceHandler.swift
//  Fastpay
//
//  Created by Anamul Habib on 5/27/20.
//  Copyright © 2020 Fastpay. All rights reserved.
//

import Foundation
import Alamofire

class WebServiceHandler{
    
    static let shared = WebServiceHandler()
    private var reachability = NetworkReachabilityManager.init()
    private init(){}
    
    @discardableResult
    func performRequest(requestBuilder: RequestBuilder, decoder: JSONDecoder = JSONDecoder(), onCompletion completion:@escaping (Data?)->Void, onFailure failure:@escaping (Error?)->Void, showLoader: Bool) -> DataRequest? {
        
        guard self.reachability?.isReachable == true else {
            showNoInternetMessage()
            return nil
        }
        
        if showLoader {DispatchQueue.main.async {Loader.sharedInstance.startAnimation()}}
        
        return Alamofire.SessionManager.default.request(requestBuilder).responseJSON { (dataResponse) in
            guard dataResponse.response?.statusCode != 401 else{
                self.requestNotAuthenticated()
                if showLoader {Loader.sharedInstance.stopAnimation()}
                return
            }
            
            print("\(((K.IS_DEV_BUILD) ? requestBuilder.baseUrl.Sandbox : requestBuilder.baseUrl.Production) + requestBuilder.path) with params: \(requestBuilder.params ?? [:]) response:\n" + (String.init(data: dataResponse.data ?? Data.init(), encoding: .utf8) ?? ""))
            
            guard dataResponse.error == nil else{
                if showLoader {DispatchQueue.main.async {Loader.sharedInstance.stopAnimation()}}
                failure(dataResponse.error)
                return
            }
            print(dataResponse.data)
            completion(dataResponse.data)
            
            if showLoader {DispatchQueue.main.async {Loader.sharedInstance.stopAnimation()}}
        }
    }
    
    private func requestNotAuthenticated(){
        DispatchQueue.main.async {
			
//			UserSettings.shared.logout()
			
        }
    }
    
    private func showNoInternetMessage(){
        DispatchQueue.main.async {
//            UserSettings.shared.mainNav?.showDialog(title: nil, message: "Internet connection appears to be offline", onDefaultActionButtonTap: nil)
        }
    }
    
    deinit {
        reachability?.stopListening()
    }
}
