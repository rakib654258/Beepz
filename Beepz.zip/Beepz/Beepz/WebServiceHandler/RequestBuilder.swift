//
//  RequestBuilder.swift
//  Beepz
//
//  Created by Rakib on 17/1/22.
//

import Foundation
import Alamofire

struct RequestBuilder : URLRequestConvertible {
    
    let baseUrl: K.BaseURL
    let path: String
    let method: HTTPMethod
    let params: [String: Any]?
    let additionalHeaders: [String: String]?
    let isEncrypted: Bool?
	
//	private let requestId: String = {
//		
//		let letters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
//		var randomString = ""
//		for _ in 0..<20{
//			let randomIndex = letters.index(letters.startIndex, offsetBy: letters.count.arc4random)
//			randomString.append(letters[randomIndex])
//		}
//		
//		return UserSettings.shared.sessionId + "$$$" + randomString + "\(Date().timeIntervalSince1970)"
//	}()
    
    init (baseUrl: K.BaseURL, path: String, method: HTTPMethod, params: [String: Any]?, additionalHeaders: [String: String]? = nil, shouldEncrypt isEncrypted: Bool? = false) {
        self.path = path
        self.method = method
        self.params = params
        self.additionalHeaders = additionalHeaders
        self.baseUrl = baseUrl
        self.isEncrypted = isEncrypted
    }
    
    
    func asURLRequest() throws -> URLRequest {
        
        let url = try (K.IS_DEV_BUILD) ? self.baseUrl.Sandbox.asURL() : self.baseUrl.Production.asURL()
        
        var urlRequest = URLRequest(url: url.appendingPathComponent(self.path))
        urlRequest.httpMethod = self.method.rawValue
        
        urlRequest.setValue(ContentType.json.rawValue, forHTTPHeaderField: HTTPHeaderField.acceptType.rawValue)
//		urlRequest.setValue(DPLanguageHandler.shared.getCurrentLanguage().identifier, forHTTPHeaderField: HTTPHeaderField.acceptLanguage.rawValue)
//		urlRequest.setValue(requestId, forHTTPHeaderField: HTTPHeaderField.requestId.rawValue)
        
        if let additionalHeaders = additionalHeaders{
            for (key, value) in additionalHeaders{
                urlRequest.setValue(value, forHTTPHeaderField: key)
            }
        }
        
//        if let apiToken = UserSettings.shared.apiToken{
//            urlRequest.setValue("Bearer \(apiToken)", forHTTPHeaderField: HTTPHeaderField.authentication.rawValue)
//        }
        
        if let parameters = self.params{
            
            if isEncrypted == true{
                // May be in future
            }else{
                urlRequest = try URLEncoding.default.encode(urlRequest, with: parameters)
            }
        }
        
        return urlRequest
    }
    
    
    enum HTTPHeaderField: String {
        case authentication = "Authorization"
        case contentType = "Content-Type"
        case acceptType = "Accept"
        case acceptEncoding = "Accept-Encoding"
		case acceptLanguage = "Accept-Language"
		case requestId = "App-request-id"
    }
    
    enum ContentType: String {
        case json = "application/json"
        case formData = "multipart/form-data"
        case urlEncoded = "application/x-www-form-urlencoded"
    }
}


fileprivate extension Int{
	var arc4random: Int{
		if self > 0 {
			return Int(arc4random_uniform(UInt32(self)))
		}
		else if self < 0{
			return -Int(arc4random_uniform(UInt32(abs(self))))
		}
		else{
			return 0
		}
	}
}
