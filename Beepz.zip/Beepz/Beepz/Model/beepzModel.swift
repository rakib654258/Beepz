//
//  BankListModel.swift
//

import Foundation

// MARK: - BankListModel

import Foundation

// MARK: - beepzModel
class beepzModel: Codable {
    let data: beepzModelDataClass?
    let code: Int?
    let message: String?
    let isSuccess: Bool?

    init(data: beepzModelDataClass?, code: Int?, message: String?, isSuccess: Bool?) {
        self.data = data
        self.code = code
        self.message = message
        self.isSuccess = isSuccess
    }
}

// MARK: - beepzModelDataClass
class beepzModelDataClass: Codable {
    let data: [beepzModelData]?

    init(data: [beepzModelData]?) {
        self.data = data
    }
}

// MARK: - beepzModelData
class beepzModelData: Codable {
    let orderId, customerId: Int?
    let customer: Customer?
    let carId: Int?
    let car: Car?
    let categoryId: Int?
    let category: Category?
    let serviceId: Int?
    let service: Service?
    let companyWiseServiceId: Int?
    let companyWiseService: CompanyWiseService?
    let numberOfBids, bidId: Int?
//    let bid: JSONNull?
    let companyId: Int?
    let company: Company?
    let orderImages: [String]?
    let carLatitude, carLongitude, readableOrderNo: String?
    let qrCodeImage: String?
    let bookingDate, bookingTime, details: String?
    let orderTrackId: Int?
    let orderTrack: Track?
    let couponId, price, vat, serviceCharge: Int?
    let subTotal, discount, grandTotal, totalRecord: Int?
    let driverId: Int?
//    let driver, orderPaypageUrl, orderReference
//    let gatewayResponse: JSONNull?
    let accidentClaimTrackId: Int?
    let accidentClaimTrack: Track?
    let address: String?
//    let emailMessage: JSONNull?

    init(orderId: Int?, customerId: Int?, customer: Customer?, carId: Int?, car: Car?, categoryId: Int?, category: Category?, serviceId: Int?, service: Service?, companyWiseServiceId: Int?, companyWiseService: CompanyWiseService?, numberOfBids: Int?, bidId: Int?,/* bid: JSONNull?,*/ companyId: Int?, company: Company?, orderImages: [String]?, carLatitude: String?, carLongitude: String?, readableOrderNo: String?, qrCodeImage: String?, bookingDate: String?, bookingTime: String?, details: String?, orderTrackId: Int?, orderTrack: Track?, couponId: Int?, price: Int?, vat: Int?, serviceCharge: Int?, subTotal: Int?, discount: Int?, grandTotal: Int?, totalRecord: Int?, driverId: Int?, /*driver: JSONNull?, orderPaypageUrl: JSONNull?, orderReference: JSONNull?, gatewayResponse: JSONNull?,*/ accidentClaimTrackId: Int?, accidentClaimTrack: Track?, address: String?/*, emailMessage: JSONNull?*/) {
        self.orderId = orderId
        self.customerId = customerId
        self.customer = customer
        self.carId = carId
        self.car = car
        self.categoryId = categoryId
        self.category = category
        self.serviceId = serviceId
        self.service = service
        self.companyWiseServiceId = companyWiseServiceId
        self.companyWiseService = companyWiseService
        self.numberOfBids = numberOfBids
        self.bidId = bidId
//        self.bid = bid
        self.companyId = companyId
        self.company = company
        self.orderImages = orderImages
        self.carLatitude = carLatitude
        self.carLongitude = carLongitude
        self.readableOrderNo = readableOrderNo
        self.qrCodeImage = qrCodeImage
        self.bookingDate = bookingDate
        self.bookingTime = bookingTime
        self.details = details
        self.orderTrackId = orderTrackId
        self.orderTrack = orderTrack
        self.couponId = couponId
        self.price = price
        self.vat = vat
        self.serviceCharge = serviceCharge
        self.subTotal = subTotal
        self.discount = discount
        self.grandTotal = grandTotal
        self.totalRecord = totalRecord
        self.driverId = driverId
//        self.driver = driver
//        self.orderPaypageUrl = orderPaypageUrl
//        self.orderReference = orderReference
//        self.gatewayResponse = gatewayResponse
        self.accidentClaimTrackId = accidentClaimTrackId
        self.accidentClaimTrack = accidentClaimTrack
        self.address = address
//        self.emailMessage = emailMessage
    }
}

// MARK: - Track
class Track: Codable {
    let accidentClaimTrackId: Int?
    let name, details: String?
    let level: Int?
    let image: String?
    let orderTrackId: Int?

    init(accidentClaimTrackId: Int?, name: String?, details: String?, level: Int?, image: String?, orderTrackId: Int?) {
        self.accidentClaimTrackId = accidentClaimTrackId
        self.name = name
        self.details = details
        self.level = level
        self.image = image
        self.orderTrackId = orderTrackId
    }
}

// MARK: - Car
class Car: Codable {
    let carId, vehicleBrandId: Int?
    let vehicleBrand: VehicleBrand?
    let vehicleModelId: Int?
    let vehicleModel: VehicleModel?
    let year, vehicleNickName: String?
    let customerId: Int?
    let customer: Customer?
    let emirateId: Int?
    let emirates: Emirate?
    let plateNumber, insuranceType, insuranceNumber, assistanceNo: String?
    let insuranceExpireDate: String?
    let image: [Image]?
    let vehicleYearId: Int?
    let vehicleYear: VehicleYear?

    init(carId: Int?, vehicleBrandId: Int?, vehicleBrand: VehicleBrand?, vehicleModelId: Int?, vehicleModel: VehicleModel?, year: String?, vehicleNickName: String?, customerId: Int?, customer: Customer?, emirateId: Int?, emirates: Emirate?, plateNumber: String?, insuranceType: String?, insuranceNumber: String?, assistanceNo: String?, insuranceExpireDate: String?, image: [Image]?, vehicleYearId: Int?, vehicleYear: VehicleYear?) {
        self.carId = carId
        self.vehicleBrandId = vehicleBrandId
        self.vehicleBrand = vehicleBrand
        self.vehicleModelId = vehicleModelId
        self.vehicleModel = vehicleModel
        self.year = year
        self.vehicleNickName = vehicleNickName
        self.customerId = customerId
        self.customer = customer
        self.emirateId = emirateId
        self.emirates = emirates
        self.plateNumber = plateNumber
        self.insuranceType = insuranceType
        self.insuranceNumber = insuranceNumber
        self.assistanceNo = assistanceNo
        self.insuranceExpireDate = insuranceExpireDate
        self.image = image
        self.vehicleYearId = vehicleYearId
        self.vehicleYear = vehicleYear
    }
}

// MARK: - Customer
class Customer: Codable {
    let customerId: Int?
    let fullName, email, phoneNumber, address: String?
    let emirateId: Int?
    let emirate: Emirate?
    let isEmailNotificationEnable: Bool?
    let createdAt: String?
    let status: Bool?
    let completedOrderCount: Int?

    init(customerId: Int?, fullName: String?, email: String?, phoneNumber: String?, address: String?, emirateId: Int?, emirate: Emirate?, isEmailNotificationEnable: Bool?, createdAt: String?, status: Bool?, completedOrderCount: Int?) {
        self.customerId = customerId
        self.fullName = fullName
        self.email = email
        self.phoneNumber = phoneNumber
        self.address = address
        self.emirateId = emirateId
        self.emirate = emirate
        self.isEmailNotificationEnable = isEmailNotificationEnable
        self.createdAt = createdAt
        self.status = status
        self.completedOrderCount = completedOrderCount
    }
}

// MARK: - Emirate
class Emirate: Codable {
    let emirateId: Int?
    let emirateName: String?
    let countryId: Int?
    let country: Country?
    let status: Bool?

    init(emirateId: Int?, emirateName: String?, countryId: Int?, country: Country?, status: Bool?) {
        self.emirateId = emirateId
        self.emirateName = emirateName
        self.countryId = countryId
        self.country = country
        self.status = status
    }
}

// MARK: - Country
class Country: Codable {
    let countryId: Int?
    let name, iso, flag, callingCode: String?
    let nationality: String?
    let status: Bool?

    init(countryId: Int?, name: String?, iso: String?, flag: String?, callingCode: String?, nationality: String?, status: Bool?) {
        self.countryId = countryId
        self.name = name
        self.iso = iso
        self.flag = flag
        self.callingCode = callingCode
        self.nationality = nationality
        self.status = status
    }
}

// MARK: - Image
class Image: Codable {
    let carImageId, carId: Int?
    let carImages: String?

    init(carImageId: Int?, carId: Int?, carImages: String?) {
        self.carImageId = carImageId
        self.carId = carId
        self.carImages = carImages
    }
}

// MARK: - VehicleBrand
class VehicleBrand: Codable {
    let vehicleBrandId: Int?
    let brandName: String?
    let icon: String?
    let details: String?
    let status: Bool?

    init(vehicleBrandId: Int?, brandName: String?, icon: String?, details: String?, status: Bool?) {
        self.vehicleBrandId = vehicleBrandId
        self.brandName = brandName
        self.icon = icon
        self.details = details
        self.status = status
    }
}

// MARK: - VehicleModel
class VehicleModel: Codable {
    let vehicleModelId: Int?
    let modelName: String?
    let icon: String?
    let details: String?
    let status: Bool?
    let vehicleBrandId: Int?
    let vehicleBrand: VehicleBrand?

    init(vehicleModelId: Int?, modelName: String?, icon: String?, details: String?, status: Bool?, vehicleBrandId: Int?, vehicleBrand: VehicleBrand?) {
        self.vehicleModelId = vehicleModelId
        self.modelName = modelName
        self.icon = icon
        self.details = details
        self.status = status
        self.vehicleBrandId = vehicleBrandId
        self.vehicleBrand = vehicleBrand
    }
}

// MARK: - VehicleYear
class VehicleYear: Codable {
    let vehicleYearId: Int?
    let details: String?
    let vehicleModelId: Int?
    let vehicleModel: VehicleModel?
    let status: Bool?

    init(vehicleYearId: Int?, details: String?, vehicleModelId: Int?, vehicleModel: VehicleModel?, status: Bool?) {
        self.vehicleYearId = vehicleYearId
        self.details = details
        self.vehicleModelId = vehicleModelId
        self.vehicleModel = vehicleModel
        self.status = status
    }
}

// MARK: - Category
class Category: Codable {
    let categoryId: Int?
    let categoryName: String?
    let icon: String?
    let details: String?

    init(categoryId: Int?, categoryName: String?, icon: String?, details: String?) {
        self.categoryId = categoryId
        self.categoryName = categoryName
        self.icon = icon
        self.details = details
    }
}

// MARK: - Company
class Company: Codable {
    let companyId: Int?
    let companyName: String?
    let userId: Int?
//    let user: JSONNull?
    let phoneNumber, email: String?
    let website: String?
    let logo: String?
    let emirateId: Int?
    let emirates: Emirate?
    let address, latitude, longitude, details: String?
    let aboutUs: String?
    let serviceCharge, companyPoint, totalReview, numberOfService: Int?
    let numberOfDriver, completedOrder, pendingOrder, totalOrder: Int?

    init(companyId: Int?, companyName: String?, userId: Int?, /*user: JSONNull?,*/ phoneNumber: String?, email: String?, website: String?, logo: String?, emirateId: Int?, emirates: Emirate?, address: String?, latitude: String?, longitude: String?, details: String?, aboutUs: String?, serviceCharge: Int?, companyPoint: Int?, totalReview: Int?, numberOfService: Int?, numberOfDriver: Int?, completedOrder: Int?, pendingOrder: Int?, totalOrder: Int?) {
        self.companyId = companyId
        self.companyName = companyName
        self.userId = userId
//        self.user = user
        self.phoneNumber = phoneNumber
        self.email = email
        self.website = website
        self.logo = logo
        self.emirateId = emirateId
        self.emirates = emirates
        self.address = address
        self.latitude = latitude
        self.longitude = longitude
        self.details = details
        self.aboutUs = aboutUs
        self.serviceCharge = serviceCharge
        self.companyPoint = companyPoint
        self.totalReview = totalReview
        self.numberOfService = numberOfService
        self.numberOfDriver = numberOfDriver
        self.completedOrder = completedOrder
        self.pendingOrder = pendingOrder
        self.totalOrder = totalOrder
    }
}

// MARK: - CompanyWiseService
class CompanyWiseService: Codable {
    let companyWiseServiceId, serviceId: Int?
    let service: Service?
    let companyId: Int?
    let company: Company?
    let price: Int?
    let vat, time: Double?
    let status: Bool?
    let details: String?

    init(companyWiseServiceId: Int?, serviceId: Int?, service: Service?, companyId: Int?, company: Company?, price: Int?, vat: Double?, time: Double?, status: Bool?, details: String?) {
        self.companyWiseServiceId = companyWiseServiceId
        self.serviceId = serviceId
        self.service = service
        self.companyId = companyId
        self.company = company
        self.price = price
        self.vat = vat
        self.time = time
        self.status = status
        self.details = details
    }
}

// MARK: - Service
class Service: Codable {
    let serviceId: Int?
    let serviceName, details: String?
    let image: String?
    let status: Bool?

    init(serviceId: Int?, serviceName: String?, details: String?, image: String?, status: Bool?) {
        self.serviceId = serviceId
        self.serviceName = serviceName
        self.details = details
        self.image = image
        self.status = status
    }
}
