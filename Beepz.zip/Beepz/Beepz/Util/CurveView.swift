//
//  CurveView.swift
//  Beepz
//
//  Created by Anamul Habib on 19/1/22.
//

import Foundation
import UIKit

@IBDesignable class CurvedHeaderView: UIView {

    @IBInspectable var curveHeight:CGFloat = 50.0
    
    var curvedLayer = CAShapeLayer()
    
    override func draw(_ rect: CGRect) {
        
        let path = UIBezierPath()
//        path.move(to: CGPoint(x: 0, y: 0))
//        path.addLine(to: CGPoint(x: rect.width, y: 0))
//        path.addLine(to: CGPoint(x: rect.width, y: rect.height))
//        path.addArc(withCenter: CGPoint(x: CGFloat(rect.width) - curveHeight, y: rect.height), radius: curveHeight, startAngle: 0, endAngle: 1.5 * CGFloat.pi, clockwise: false)
//        path.addLine(to: CGPoint(x: curveHeight, y: rect.height - curveHeight))
//        path.addArc(withCenter: CGPoint(x: curveHeight, y: rect.height - (curveHeight * 2.0)), radius: curveHeight, startAngle: 0, endAngle:  CGFloat.pi, clockwise: true)
        
        path.move(to: CGPoint(x: rect.width - 60, y: 0))
//        path.addArc(withCenter: CGPoint(x: rect.width - 20, y: 0), radius: 80, startAngle: CGFloat(Double.pi/2 * 3), endAngle: CGFloat(Double.pi), clockwise: true)
       // path.addArc(withCenter: CGPoint(x: rect.width - 160, y: -80), radius: 80, startAngle: CGFloat(Double.pi/2 * 3), endAngle: CGFloat(Double.pi * 0), clockwise: false)
        
        path.addCurve(to: CGPoint(x: rect.width/2, y: rect.height/2), controlPoint1: CGPoint(x: 80, y: 22), controlPoint2: CGPoint(x: 67, y: 78))
        path.addCurve(to: CGPoint(x: 0, y: rect.height), controlPoint1: CGPoint(x: 34, y: 37), controlPoint2: CGPoint(x: 45, y: 67))
        
        path.addLine(to: CGPoint(x: rect.width, y: rect.height))
        path.addLine(to: CGPoint(x: rect.width, y: 0))
        
        path.close()
        
        curvedLayer.path = path.cgPath
        curvedLayer.fillColor = UIColor(red: 253/255, green: 242/255, blue: 238/255, alpha: 1.0).cgColor
        curvedLayer.frame = rect
        
        self.layer.insertSublayer(curvedLayer, at: 0)
        
//        self.layer.shadowColor = UIColor.black.cgColor
//        self.layer.shadowRadius = 10.0
//        self.layer.shadowOpacity = 0.7
    }
    
}
