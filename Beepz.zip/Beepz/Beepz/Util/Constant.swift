//
//  Constant.swift
//  Fastpay
//
//  Created by Rakib on 5/27/20.
//

import Foundation
import UIKit

struct K {
    private init(){}
    
    static let IS_DEV_BUILD = true
    static let IS_SERVER_COMMUNICATION_ENCRYPTED = false
    
    struct NotificationKey {
        private init(){}
        
        static let DPMenuOpen = "dkMenuToggleNotificationKey"
    }
    
    enum BaseURL{
        
        case Beepz
        
        var Sandbox: String {
            switch self {
            case .Beepz:
                return "https://beepz.ae/api/v1/"
            }
            
        }
        
        var Production: String {
            switch self {
            case .Beepz:
                return "https://beepz.ae/api/v1/"
            }
        }
    }
    
    
    struct UserDefaultsKey {
        private init(){}
        
        static let APITokenKey = "api_tokn_key"
        static let AccessTokenKey = "dk_access_token_key"
        static let RefreshTokenKey = "dk_refresh_token_key"
        static let UserMobileNo = "dk_user_mobile_number_key"
        static let UserPassword = "dk_alskdf34343faw124324"
        static let ActiveLanguageIndex = "dk_ActiveLanguageIndexKey_key"
        static let FCMToken = "dk_FCMTokenKey"
        static let BiometricAuthTypeId = "biometricAuthTypeKeyId"
        static let RememberUserKey = "dk_rememberUserKey"
    }
    
    struct UI {
        
        private init(){}
        
        enum FontName{
            case lato
            case proximaNova
        }
        
        enum FontStyle {
            case regular
            case italic
            case hairline
            case hairlineItalic
            case light
            case lightItalic
            case medium
            case bold
            case boldItalic
            case black
            case blackItalic
        }
        
        static func appFont(ofSize size: CGFloat, style: FontStyle, font: FontName) -> UIFont?{
            
            switch font{
            
            case .lato:
                switch style{
                
                case .regular:
                    return UIFont.init(name: "Lato-Regular", size: size)
                case .italic:
                    return UIFont.init(name: "Lato-Italic", size: size)
                case .hairline:
                    return UIFont.init(name: "Lato-Hairline", size: size)
                case .hairlineItalic:
                    return UIFont.init(name: "Lato-HairlineItalic", size: size)
                case .light:
                    return UIFont.init(name: "Lato-Light", size: size)
                case .lightItalic:
                    return UIFont.init(name: "Lato-LightItalic", size: size)
                case .medium:
                    return UIFont.init(name: "Lato-Medium", size: size)
                case .bold:
                    return UIFont.init(name: "Lato-Bold", size: size)
                case .boldItalic:
                    return UIFont.init(name: "Lato-BoldItalic", size: size)
                case .black:
                    return UIFont.init(name: "Lato-Black", size: size)
                case .blackItalic:
                    return UIFont.init(name: "Lato-BlackItalic", size: size)
                }
                
            case .proximaNova:
                switch style{
                case .regular:
                    return UIFont.init(name: "ProximaNova-Regular", size: size)
                    
                default: return nil
                }
            }
        }
        
        static let TabBarMinimumHeight: CGFloat = 66.0
        static let TabBarMinimumHeightIpad: CGFloat = 86.0
        static let StatusBarHeight: CGFloat = UIApplication.shared.statusBarFrame.size.height
        
        static let MainScreenBounds = UIScreen.main.bounds
        
        static var BottomSafeAreaInsetForNewerIphones: CGFloat {
            if #available(iOS 11.0, *) {
                let window = UIApplication.shared.keyWindow
                let bottomPadding = window?.safeAreaInsets.bottom
                
                return bottomPadding ?? 0.0
            }else{
                return 0.0
            }
        }
        
        static let PrimaryTintColor = #colorLiteral(red: 0.9931514859, green: 0.1864635348, blue: 0, alpha: 1)
        static let AppBackgroundColor = #colorLiteral(red: 0.07219018787, green: 0.07348110527, blue: 0.1315894723, alpha: 1)
        static let DisabledButtonBackgroundColor = #colorLiteral(red: 0.168627451, green: 0.2, blue: 0.368627451, alpha: 1)
        static let AppGreenColor = #colorLiteral(red: 0.01176470588, green: 0.9215686275, blue: 0.6392156863, alpha: 1)
        static let PlacehoderColor = #colorLiteral(red: 0.168627451, green: 0.2, blue: 0.368627451, alpha: 0.3)
        static let shadowColor = #colorLiteral(red: 0.8392156863, green: 0.8392156863, blue: 0.8392156863, alpha: 1)
    }
    
    struct Messages {
        static let DefaultErrorMessage = "error"
        static let DefaultSuccessMessage = "success"
        static let DefaultMemberDoLikeWarningMessage = "Only members can do like and comment!"
    }
    
    struct Misc {
        static let GOOGLE_MAP_API_KEY = "AIzaSyDae90WeTi0Qto5FMbU95qu8DSZP0lilwA"
        static let baseCountryId = 103
        static let MobileNoLength = 11
        static let CountryCode = "+88"
        static let desiredImageSizeInBytes = 1000*1000
        static let otpLength = 6
        static let trxPINLength = 4
        static let PINLength = 4
    }
}


enum PaymentPurpose{
    case signup
    case memebershipChange
}

enum PaymentProcessor: String{
    case stripe = "stripe"
    case paypal = "paypal"
}
