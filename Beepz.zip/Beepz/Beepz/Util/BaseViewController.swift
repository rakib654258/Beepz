//
//  ViewController.swift
//  Beepz
//
//  Created by Rakib on 17/1/22.
//

import UIKit

class BaseViewController: UIViewController, UITextFieldDelegate, UITextViewDelegate {
	
	private(set) var scrollViewToOverride: UIScrollView?
	private(set) var containerViewToOverride: UIView?
	private(set) var containerViewTopSpaceConstraintToOverride: NSLayoutConstraint?
	private var activeFieldFrame: CGRect?
	private var containerViewOriginalFrame: CGRect!
	private var containerViewTopSpaceConstraintOriginalConstant: CGFloat!
	private(set) var shouldConfigureReturnKeyBasedOnTag: Bool = true
	private(set) var shouldAddToolbarToTextFieldWithSpecialKeyboardType: Bool = true
    private(set) var textFieldToolBarDoneButtonTitle: String = "Done"
    private(set) var textFieldToolBarNextButtonTitle: String = "Next"
    private(set) var tintColor: UIColor = K.UI.PrimaryTintColor
	private(set) var navigationBarTitleViewImage: UIImage?
	//private(set) var shouldRewindByTappingTitleView = true
    private(set) var shouldHaveNavigationBarShadow = false
	private(set) var shouldShowNotificationButtonOnNavigationBar = false
	private(set) var shouldHaveBackButtonTitle = false
    private(set) var dkTitle: String?
    private(set) var shouldShowTitle = true
    private(set) var shouldHaveCustomBackButtonTitle = false
    private(set) var shouldShowBackButtonTitle = true
    
//	private let notificationButton = BadgeBarButtonItem.init()
	
	var firstTimeAppearing = true
	
//	let usersettings = UserSettings.shared
	let webserviceHandler = WebServiceHandler.shared
    
    
    
	
	override func viewDidLoad() {
		
		super.viewDidLoad()
		
        view.tintColor = tintColor
        
		registerForKeyboardNotifications()
		
        
        if let navBarTitleImage = navigationBarTitleViewImage{
            self.navigationItem.titleView = UIImageView.init(image: navBarTitleImage)
        }
        
      //  self.navigationItem.backBarButtonItem = UIBarButtonItem(title: (shouldHaveBackButtonTitle) ? "Back" : nil, style: .plain, target: nil, action: nil)
        
        
        if shouldShowBackButtonTitle{
            
            if shouldHaveBackButtonTitle{
                let imgBack = UIImage(named: "back")
                self.navigationController?.navigationBar.backIndicatorImage = imgBack
                self.navigationController?.navigationBar.backIndicatorTransitionMaskImage = imgBack
                self.navigationItem.leftItemsSupplementBackButton = true
                
                self.navigationController?.navigationBar.topItem?.backBarButtonItem = UIBarButtonItem(title: "Back", style: .plain, target: self, action: nil)

            }else{
                
                if shouldHaveCustomBackButtonTitle{
                    
                }else{
                    setNavigationBack()
                }
            }
        }
        
        if shouldShowTitle{
            
            let customView = UIView(frame: CGRect(x: 0.0, y: 0.0, width: UIScreen.main.bounds.size.width - 100, height: 44.0))
            customView.backgroundColor = UIColor.clear
            labl = UILabel(frame: CGRect(x: 26, y: 0.0, width: customView.frame.size.width - 26, height: 44.0))
            labl.text = ""
            labl.font = UIFont.systemFont(ofSize: 20, weight: .medium)
            labl.textColor = #colorLiteral(red: 0.09803921569, green: 0.1098039216, blue: 0.1019607843, alpha: 1)
            labl.textAlignment = NSTextAlignment.left
            labl.backgroundColor = UIColor.clear
            customView.addSubview(labl)
            let leftButton = UIBarButtonItem(customView: customView)
            self.navigationItem.leftBarButtonItems?.append(leftButton)
        }
	}
    
    
    var labl = UILabel()
    func updateTitle(str: String){
        labl.text = str
        print(str)
    }
    
    func setNavigationBack() {
        
        let rightNavBtn =  UIButton(type: .custom)
        rightNavBtn.frame = CGRect(x: 12, y: 0, width: 22, height: 24)
        rightNavBtn.backgroundColor = .clear
        rightNavBtn.setImage(#imageLiteral(resourceName: "back"), for: .normal)
        rightNavBtn.addTarget(self, action: #selector(backActionBase), for: .touchUpInside)
        self.navigationItem.setLeftBarButton(UIBarButtonItem(customView: rightNavBtn), animated: true);
    }
    
    @objc func backActionBase() {
        self.navigationController?.popViewController(animated: true)
    }
    
    
    func makeNavigationBarTransparent(){
        
        if #available(iOS 13.0, *) {
            let appearance = UINavigationBarAppearance()
            appearance.configureWithTransparentBackground()
//            appearance.backgroundColor = .white
            appearance.setBackIndicatorImage(UIImage.init(named: "back"), transitionMaskImage: UIImage.init(named: "back"))
            self.navigationController?.navigationBar.standardAppearance = appearance;
            self.navigationController?.navigationBar.scrollEdgeAppearance = self.navigationController?.navigationBar.standardAppearance
            self.navigationController?.navigationBar.tintColor = .white
        }
        
        self.navigationController?.navigationBar.setBackgroundImage(UIImage(), for: .default) //UIImage.init(named: "transparent.png")
        self.navigationController?.navigationBar.shadowImage = UIImage()
        self.navigationController?.navigationBar.isTranslucent = true
//        self.navigationController?.view.backgroundColor = .clear
    }
    
    func makeNavigationBarNonTransparent(){
        
        if #available(iOS 13.0, *) {
            let appearance = UINavigationBarAppearance()
            appearance.configureWithOpaqueBackground()
            appearance.backgroundColor = .white
            appearance.setBackIndicatorImage(UIImage.init(named: "back"), transitionMaskImage: UIImage.init(named: "back"))
            self.navigationController?.navigationBar.standardAppearance = appearance;
            self.navigationController?.navigationBar.scrollEdgeAppearance = self.navigationController?.navigationBar.standardAppearance
        }
        
        self.navigationController?.navigationBar.setBackgroundImage(nil, for: .default) //UIImage.init(named: "transparent.png")
        self.navigationController?.navigationBar.shadowImage = nil
        self.navigationController?.navigationBar.isTranslucent = false
    }
    
    func shouldHideNavigationBar(_ shouldHide: Bool){
        self.navigationController?.navigationBar.isHidden = shouldHide
    }
	
    override func viewWillAppear(_ animated: Bool) {
        
        super.viewWillAppear(animated)
        
        
        if !shouldHaveNavigationBarShadow{
            
                if #available(iOS 13.0, *) {
                    let appearance = UINavigationBarAppearance()
                    appearance.configureWithTransparentBackground()
                    appearance.backgroundColor = .white
                    appearance.setBackIndicatorImage(UIImage.init(named: "back"), transitionMaskImage: UIImage.init(named: "back"))
                    self.navigationController?.navigationBar.standardAppearance = appearance;
                    self.navigationController?.navigationBar.scrollEdgeAppearance = self.navigationController?.navigationBar.standardAppearance
                }
                
            self.navigationController?.navigationBar.setBackgroundImage(UIImage(), for: .default)
            self.navigationController?.navigationBar.shadowImage = UIImage()
        }else{
            
            if #available(iOS 13.0, *) {
                let appearance = UINavigationBarAppearance()
                appearance.configureWithOpaqueBackground()
                appearance.backgroundColor = .white
                appearance.setBackIndicatorImage(UIImage.init(named: "back"), transitionMaskImage: UIImage.init(named: "back"))
                self.navigationController?.navigationBar.standardAppearance = appearance;
                self.navigationController?.navigationBar.scrollEdgeAppearance = self.navigationController?.navigationBar.standardAppearance
            }
            
            self.navigationController?.navigationBar.setBackgroundImage(nil, for: .default)
            self.navigationController?.navigationBar.shadowImage = nil
        }
    }
	
	override func viewWillDisappear(_ animated: Bool) {
		super.viewWillDisappear(animated)
		
		//self.presentedViewController?.dismiss(animated: true, completion: nil)
		view.endEditing(true)
        //removeAttributedTitle()
	}
	
	override func viewDidAppear(_ animated: Bool) {
		
		super.viewDidAppear(animated)
		containerViewOriginalFrame = containerViewToOverride?.frame
		containerViewTopSpaceConstraintOriginalConstant = containerViewTopSpaceConstraintToOverride?.constant

	}
	
	private func registerForKeyboardNotifications() {
		
		NotificationCenter.default.addObserver(self, selector: #selector(self.onKeyboardAppear(_:)), name: UIResponder.keyboardWillShowNotification, object: nil)
		NotificationCenter.default.addObserver(self, selector: #selector(self.onKeyboardDisappear(_:)), name: UIResponder.keyboardWillHideNotification, object: nil)
	}
	
	
	@objc private func onKeyboardAppear(_ notification: NSNotification) {
		
		if let info = notification.userInfo, let activeFieldFrame = activeFieldFrame {
			
			let rect: CGRect = info[UIResponder.keyboardFrameEndUserInfoKey] as! CGRect
			let keyboardSize = rect.size
			
			// WITH SCROLLVIEW
			if let scrollView = scrollViewToOverride {
				
				pushUpFor(scrollView: scrollView, activeFieldFrame: activeFieldFrame, keyboardSize: keyboardSize)
				
				//WITH OUT SCROLLVIEW
			}else{
				
				//WITH AUTOLAYOUT CONSTRAINT
				if let containerViewTopSpaceConstraint = containerViewTopSpaceConstraintToOverride{
					
					pushUpFor(containerViewTopSpaceConstraint: containerViewTopSpaceConstraint, activeFieldFrame: activeFieldFrame, keyboardSize: keyboardSize)
					
					//WITHOUT AUTOLAYOUT CONSTRAINT, FRAME BASED
				}else{
					
					if let containerView = containerViewToOverride {
						
						pushUpFor(containerView: containerView, activeFieldFrame: activeFieldFrame, keyboardSize: keyboardSize)
					}
				}
			}
		}
	}
	
	@objc private func onKeyboardDisappear(_ notification: NSNotification) {
		
		// WITH SCROLLVIEW
		if let scrollView = scrollViewToOverride{
			
			scrollView.contentInset = .zero
			scrollView.scrollIndicatorInsets = .zero
			
			//WITHOUT SCROLLVIEW
		}else{
			
			//WITH AUTOLAYOUT CONSTRAINT
			if let containerViewTopSpaceConstraint = containerViewTopSpaceConstraintToOverride{
				
				if containerViewTopSpaceConstraint.constant != containerViewTopSpaceConstraintOriginalConstant{
					
					UIView.animate(withDuration: TimeInterval(0.5)) {
						containerViewTopSpaceConstraint.constant = self.containerViewTopSpaceConstraintOriginalConstant
					}
					view.setNeedsUpdateConstraints()
				}
				
				//WITHOUT AUTOLAYOUT CONSTRAINT, FRAME BASED
			}else{
				
				if let containerView = containerViewToOverride{
					
					if containerView.frame.origin.y != containerViewOriginalFrame.origin.y{
						
						UIView.animate(withDuration: TimeInterval(0.5)) {
							containerView.frame.origin.y = self.containerViewOriginalFrame.origin.y
						}
						view.layoutIfNeeded()
					}
				}
			}
		}
	}
	
	private func pushUpFor(scrollView: UIScrollView, activeFieldFrame: CGRect, keyboardSize: CGSize){
		
		var aRect = self.view.bounds;
		aRect.size.height -= keyboardSize.height;
		
		let insets = UIEdgeInsets(top: 0, left: 0, bottom: keyboardSize.height, right: 0)
		scrollView.contentInset = insets
		scrollView.scrollIndicatorInsets = insets
		
		if !aRect.contains(activeFieldFrame.origin) {
			scrollView.scrollRectToVisible(activeFieldFrame, animated: true)
		}
	}
	
	private func pushUpFor(containerViewTopSpaceConstraint: NSLayoutConstraint, activeFieldFrame: CGRect, keyboardSize: CGSize){
		
		var aRect = self.view.bounds;
		aRect.size.height -= keyboardSize.height;
		
		if !aRect.contains(activeFieldFrame.origin){
			
			if containerViewTopSpaceConstraint.constant == containerViewTopSpaceConstraintOriginalConstant{
				
				UIView.animate(withDuration: TimeInterval(0.5)) {
					containerViewTopSpaceConstraint.constant -= keyboardSize.height
				}
				view.setNeedsUpdateConstraints()
			}
		}
	}
	
	private func pushUpFor(containerView: UIView, activeFieldFrame: CGRect, keyboardSize: CGSize){
		
		var aRect = containerView.bounds;
		aRect.size.height -= keyboardSize.height
		
		//if rect.intersects(activeFieldFrame){
		if !aRect.contains(activeFieldFrame.origin){
			
			if containerView.frame.origin.y == containerViewOriginalFrame.origin.y {
				
				UIView.animate(withDuration: TimeInterval(0.5)) {
					containerView.frame.origin.y -= keyboardSize.height
				}
				view.layoutIfNeeded()
			}
		}
	}
	
	
	private func determineReturnKeyTypeForResponder(withTag tag: Int) -> UIReturnKeyType {
		
		let nextTag = tag + 1
		let nextResponder = view.viewWithTag(nextTag)
		
		if nextResponder != nil {
			return .next
		} else {
			return .done
		}
	}
	
	private func addBasicActionToReturnKeyOfTextField(withTag tag: Int) -> Bool{
		
		let nextTag = tag + 1
		let nextResponder = view.viewWithTag(nextTag)
		
		if nextResponder != nil {
			
			nextResponder?.becomeFirstResponder()
			return true
		} else {
			
			view.endEditing(true)
			return false
		}
	}
	
	private func addToolBar(toTextField textField: UITextField){
		
		let toolBar = UIToolbar()
		toolBar.barStyle = UIBarStyle.default
		toolBar.isTranslucent = true
        toolBar.tintColor = K.UI.PrimaryTintColor
		
		let actionButton = UIBarButtonItem(title: (determineReturnKeyTypeForResponder(withTag: textField.tag) == .next) ? textFieldToolBarNextButtonTitle : textFieldToolBarDoneButtonTitle, style: UIBarButtonItem.Style.plain, target: self, action: #selector(doneOrNextPressed(_:)))
		actionButton.tag = textField.tag
		
		let spaceButton = UIBarButtonItem(barButtonSystemItem: UIBarButtonItem.SystemItem.flexibleSpace, target: nil, action: nil)
		
		toolBar.setItems([spaceButton, actionButton], animated: false)
		toolBar.isUserInteractionEnabled = true
		toolBar.sizeToFit()
		
		textField.inputAccessoryView = toolBar
	}
	
	@objc private func doneOrNextPressed(_ button: UIBarButtonItem){
		
		_ = addBasicActionToReturnKeyOfTextField(withTag: button.tag)
	}
	
	
	func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
		
		activeFieldFrame = textField.frame
		
		return true
	}
	
	func textFieldDidBeginEditing(_ textField: UITextField) {
		
		view.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(self.tapDetected(_:))))
		
		if shouldConfigureReturnKeyBasedOnTag && textField.returnKeyType == .default {
			textField.returnKeyType = determineReturnKeyTypeForResponder(withTag: textField.tag)
		}
		
		var shouldHaveToolBar: Bool
		if #available(iOS 10.0, *) {
			shouldHaveToolBar = shouldAddToolbarToTextFieldWithSpecialKeyboardType && (textField.keyboardType == .numberPad || textField.keyboardType == .phonePad || textField.keyboardType == .decimalPad || textField.keyboardType == .asciiCapableNumberPad) || (textField.inputView is UIPickerView)
		} else {
			shouldHaveToolBar = shouldAddToolbarToTextFieldWithSpecialKeyboardType && (textField.keyboardType == .numberPad || textField.keyboardType == .phonePad || textField.keyboardType == .decimalPad) || (textField.inputView is UIPickerView)
		}
		
		if shouldHaveToolBar {
			addToolBar(toTextField: textField)
		}else{
			textField.inputAccessoryView = nil
		}
	}
	
	func textFieldDidEndEditing(_ textField: UITextField) {
		//checkInputs()
	}
	
	func textViewShouldBeginEditing(_ textView: UITextView) -> Bool {
		
		activeFieldFrame = textView.frame
		
		return true
	}
	
	func textViewDidBeginEditing(_ textView: UITextView) {
		
		view.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(self.tapDetected(_:))))
	}
	
	func textFieldShouldReturn(_ textField: UITextField) -> Bool {
		
		if shouldConfigureReturnKeyBasedOnTag{
			
			return addBasicActionToReturnKeyOfTextField(withTag: textField.tag)
		}
		
		return true
	}
	
	
	
	@objc private func tapDetected(_ tapRecognizer: UITapGestureRecognizer?) {
		
		view.endEditing(true)
		if let tapRecognizer = tapRecognizer {
			view.removeGestureRecognizer(tapRecognizer)
		}
	}
	
    func showDialog(title: String?, message: String, defaultActionButtonTitle: String = "Ok", onDefaultActionButtonTap defaultButtonAction: (()->())?){
        let alert = UIAlertController(title: title , message: message, preferredStyle: UIAlertController.Style.alert)
        alert.addAction(UIAlertAction(title: defaultActionButtonTitle, style: .default, handler: { action in
            if let defaultButtonAction = defaultButtonAction{
                defaultButtonAction()
            }
        }))
        
        alert.view.tintColor = view.tintColor
        self.present(alert, animated: true, completion: nil)
    }
    
	
	@objc func checkInputs(){
		
	}
	
	func showLoader(){
		Loader.sharedInstance.startAnimation()
	}
	
	func hideLoader(){
		Loader.sharedInstance.stopAnimation()
	}
	
	func formatMobileNumberEscapingSpecialChar(_ mobileNumber: String?) -> String {
		var mobileNumber = mobileNumber
		//mobileNumber = mobileNumber?.replacingOccurrences(of: "(", with: "")
		//mobileNumber = mobileNumber?.replacingOccurrences(of: ")", with: "")
		mobileNumber = mobileNumber?.replacingOccurrences(of: " ", with: "")
		//mobileNumber = mobileNumber?.replacingOccurrences(of: "-", with: "")
		//mobileNumber = mobileNumber?.replacingOccurrences(of: "+", with: "")
		
		return mobileNumber ?? ""
		
		print("\(mobileNumber ?? "")")
		
		let length = mobileNumber?.count ?? 0
		if length > 10 {
			mobileNumber = (mobileNumber as NSString?)?.substring(from: length - 10)
			print("\(mobileNumber ?? "")")
		}
		
		return mobileNumber ?? ""
	}
	
	func getMobileNoLengthEscapingSpecialChar(_ mobileNumber: String?) -> Int {
		var mobileNumber = mobileNumber
		mobileNumber = mobileNumber?.replacingOccurrences(of: "(", with: "")
		mobileNumber = mobileNumber?.replacingOccurrences(of: ")", with: "")
		mobileNumber = mobileNumber?.replacingOccurrences(of: " ", with: "")
		mobileNumber = mobileNumber?.replacingOccurrences(of: "-", with: "")
		mobileNumber = mobileNumber?.replacingOccurrences(of: "+", with: "")
		
		let length = mobileNumber?.count ?? 0
		
		return length
	}
	
	deinit {
		
		NotificationCenter.default.removeObserver(self, name: UIResponder.keyboardWillShowNotification, object: nil)
		NotificationCenter.default.removeObserver(self, name: UIResponder.keyboardWillHideNotification, object: nil)
	}
	
    func mobileNumberValidateNmb(_ mobileNumber: String)-> Int{
        let result = String(mobileNumber.prefix(1))
        if result == "0"{
            return (K.Misc.MobileNoLength + 1)
        }else{
            return K.Misc.MobileNoLength
        }
    }

    func isBellowiPhone8Srs(prntSize : String)-> Bool{
        if let size = Double(prntSize){
            if size > 5.5{
            }else{
                return true
            }
        }
        return false
    }
    
    func getScreenSize()-> String{
        let scale = UIScreen.main.scale

        let ppi = scale * ((UIDevice.current.userInterfaceIdiom == .pad) ? 132 : 163);

        let width = UIScreen.main.bounds.size.width * scale
        let height = UIScreen.main.bounds.size.height * scale

        let horizontal = width / ppi, vertical = height / ppi;

        let diagonal = sqrt(pow(horizontal, 2) + pow(vertical, 2))
        let screenSize = String(format: "%0.1f", diagonal)
        
        print("screenSize : \(screenSize)")
        
        return screenSize
    }
    
    // MARK: - navigation title text and image
    func navTitleWithImage() {

        let rect:CGRect = CGRect.init(origin: CGPoint.init(x: -128, y: 0), size: CGSize.init(width: 64, height: 64))

        let titleView:UIView = UIView.init(frame: rect)
        /* image */
        let image:UIImage = UIImage.init(named: "beepz")!
        let image_view:UIImageView = UIImageView.init(image: image)
        image_view.frame = CGRect.init(x: 0, y: 0, width: 24, height: 24)
        image_view.center = CGPoint.init(x: titleView.center.x, y: titleView.center.y - 10)
//        image_view.layer.cornerRadius = image_view.bounds.size.width / 2.0
        image_view.layer.masksToBounds = true
        titleView.addSubview(image_view)

        /* label */
        let label:UILabel = UILabel.init(frame: CGRect.init(x: -120, y: 30, width: 120, height: 24))
        label.text = "Beepz"
        label.textColor = .white
        label.font = UIFont.systemFont(ofSize: 24)
        label.textAlignment = .center
        titleView.addSubview(label)

        self.navigationItem.titleView = titleView

    }
    
}

extension UIView{
    func addViewShadow(scale: Bool = true) {
        self.layer.masksToBounds = false
        layer.shadowColor = #colorLiteral(red: 0.501960814, green: 0.501960814, blue: 0.501960814, alpha: 1)
        layer.shadowOffset = CGSize(width: 0.0, height: 0.0)
        layer.shadowRadius = 5.0
        layer.shadowOpacity = 0.7
    }
}
